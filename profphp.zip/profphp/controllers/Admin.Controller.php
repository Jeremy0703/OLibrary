<?php
if(!$_SESSION["connect"])
{
	$_SESSION["erreur"] = "Veuillez vous connecter avec des identifiants valides pour accéder à la page http://localhost/profphp/admin";
	header("Location: http://localhost/profphp/login/");
}

if(!empty($_SESSION["erreur"]))
{
	echo "<div>".$_SESSION["erreur"]."</div>";
	unset($_SESSION["erreur"]);
	

}
require $_dir["views"]."back/accueil.php";
<?php
require $_dir["views"]."back/affichage.php";
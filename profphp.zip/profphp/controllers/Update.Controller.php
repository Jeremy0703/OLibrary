<?php
if (!empty($_POST)) // si le formulaire est envoyé
{
	
		if (!empty($_POST["id"]) AND !empty($_POST["email"])) 
		{
				$id = (int)$_POST["id"];
				$nom = $_POST["nom"];
				$prenom = $_POST["prenom"];
				$email = $_POST["email"];
				$password = md5($_POST["password"]);

				$user = $bdd->query("SELECT * FROM users WHERE id=".$id);
				$user = $user->fetch();
				if (!empty($user)) {
						$bdd->query("UPDATE users SET nom='".$nom."', prenom='".$prenom."', email='".$email."', password='".$password."' WHERE id=".$_GET["id"]);
						$_SESSION["erreur"] = "Vous venez de modifier l'utilisateur";
						header("Location: http://localhost/profphp/admin/");
				}
				else {
						$_SESSION["erreur"] = "L'ID fourni ne correspond a aucun utilisateur";
						header("Location: http://localhost/profphp/admin/");		
				}
		}
}


elseif(!empty($_GET["id"])) // sinon si  il y a un id 

{
		$id = (int)$_GET["id"];
		$user = $bdd->query("SELECT * FROM users WHERE id = ".$id); // requete
		$user = $user->fetch();
		if(!empty($user)) //si la reque me returne un user
		{
			require $_dir["views"]."update.php"; //retour la vue
			
		}

		else //sinon
		{
			$_SESSION["erreur"]= "l'id foruni n'est pas un user";
			header("Location: http://localhost/profphp/admin/");
		}

}



//header("Location: http://localhost/profphp/views/update");

//$bdd->query("UPDATE users SET id='".$_POST["id"]."', nom='".$_POST["nom"]."', prenom='".$_POST["prenom"]."', email='".$_POST["email"]."', password='".$_POST["password"]."' ");
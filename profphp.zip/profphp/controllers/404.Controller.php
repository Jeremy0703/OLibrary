<?php
require $_dir["views"]."404.php";
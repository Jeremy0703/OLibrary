<?php
if(!empty($_POST))
{
	$req = $bdd->query("SELECT * FROM users 
	WHERE email='".$_POST["email"]."'
	AND password='".md5($_POST["password"])."' ");
	$user = $req->fetch();
	if(!empty($user)) //si login/mdp est bon
	{
		$_SESSION["connect"] = true;

		header('Location: http://localhost/profphp/admin/');
	}
	else //sinon
	{
		$_SESSION["erreur"] = "VEUILLEZ SAISIR DES INFORMATIONS VALIDES";
	}
}
if(!empty($_SESSION["erreur"]))
{
	echo 
	"<div>
	".$_SESSION["erreur"]."
	</div>";
	unset($_SESSION["erreur"]);
	
}
require $_dir["views"]."login.php";
<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
    
    <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="/phpmyadmin/">PhpMyAdmin</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggli<button type="button" class="btn btn-default">ng -->
    <button style="margin-top: 7px;" type="button" class="btn btn-default"> 
        <a href="/profphp/deconnexion/">Deconnexion</a>
    </button>
      
      <ul class="nav navbar-nav navbar-right">
        <li><a href="/profphp">Back to home</a></li>
       
        </li>
        <li><a href="/profphp/affichage">Users list</a></li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>




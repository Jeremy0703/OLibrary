<?php 

//echo $user['nom'];

echo "Utilisateurs actuels de notre site :";


$users = $bdd->query("SELECT * FROM users");

foreach($users as $user)
{
    echo "<TABLE border='1'>
    		
    			<TR>
    				<TH> id </TH>
    				<TH> prenom </TH>
    				<TH> nom </TH>
    				<TH> email </TH>
    				
    				<TH> delete </TH>
    				<TH> update </TH>
    			</TR>
    			<TR>
    				<TD>".$user["id"]." </TD>
    				<TD>".$user["prenom"]." </TD>
    				<TD>".$user["nom"]." </TD>
    				<TD>".$user["email"]." </TD>
    				
    				<TD><a href='/profphp/suppression/?id=".$user["id"]."' >supprimer</a></TD>
    				<TD><a href='/profphp/update/?id=".$user["id"]."' >Modifier</a></TD>
    			</TR>
    	</TABLE>";
}

$users->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
	
	<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="/phpmyadmin/">PhpMyAdmin</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    
      <form class="navbar-form navbar-left" method="post" action="">
        <div class="form-group">
          <input name="email" type="text" class="form-control" >
          <input name="password" type="password" class="form-control">

        </div>
        <button type="submit" class="btn btn-default">S'Authentifier</button>
      </form>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="/profphp">Retour Accueil</a></li>
       
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

	
	<div id="icon" style="width: 300px; height: 400px; padding-top: 10px; padding-left: 2px;margin-left: 600px; margin-top: 100px; border: solid 10px; text-align: center; ">
		<a href="#">
			<h1>OL Library Project</h1>
			<img src="/profphp/images/book-flat.png" alt="ollibrary project" title="icon book" style="margin:auto; text-align:center;">
		</a>
	</div>
	




</body>
</html>



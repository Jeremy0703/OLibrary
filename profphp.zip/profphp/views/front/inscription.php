<h3>     •   INSCRIS-TOI</h3>
<form method="POST" action="">
    <input type="text" name="prenom" placeholder="prenom"/>
    <input type="text" name="nom" placeholder="nom"/>
    <input type="text" name="email" placeholder="email"/>

    <input type="password" name="password"/>
    <input type="submit" value="s'inscrire"/>
</form>

<?php

if(!empty($_POST))
{
    
    $bdd->query("INSERT INTO users (nom,prenom,email,password)
   VALUES ('".$_POST["nom"]."', '".$_POST["prenom"]."', '".$_POST["email"]."', '".md5($_POST["password"])."') ");

    echo "nouvel utilisateur créé";

    
}


?>


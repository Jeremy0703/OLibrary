<html>
    <head>
        <meta charset="UTF-8"/>
        <link href="/olibrairy/views/front/css/inscription.css" type="text/css" rel="stylesheet"/>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <meta description = "page d'inscription ACG"/>
        <link rel="icon" type="image/png" href="/olibrairy/views/front/images/livre_oiseau.png"/>
        <title>Page d'inscription</title>
    </head>

    <body>
      <nav class="navbar navbar-inverse" style="width:100%">
        <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
          <div class="navbar-header">
      
            <ul class="nav navbar-nav navbar-left">
              <li style=""><a href="/olibrairy"><img src="/olibrairy/images/book-flat.png" style="width: 50px; height: 50px; margin-right: 40px;">Retour Accueil</a></li>
    <!-- Collect the nav links, forms, and other content for toggling -->
            </ul>
          </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
      </nav>
<!image du logo/>
        <a href="#">
            <img id="logo" src="/olibrairy/views/front/images/homme-tete-de-livre.jpg">
        </a>
<!On fais le cadre principal/>
        <div id="principal">
<!Titre/>
            <h1 id="inscription">Inscription</h1>
            
<!On crée les indications nom, prenotout permet de les mettres a gauche/>
           
            <form method="post" action="">

              <div class="tout">
              
               <p class="id">Nom*</p>
                  <input class="user" type="text" name="nom" placeholder="Nom"/>
              </div>

             <div class="tout">
               <p class="id">Prenom*</p>
                  <input class="user" type="text" name="prenom" placeholder="Prénom"/>
              </div>

              <div class="tout">
               <p class="id">E-mail*</p>
                 <input class="user" type="text" name="email" placeholder="E-mail"/>
              </div>


              <div class="tout">
               <p class="id">Mot de Passe*</p>
                  <input class="user" type="password" name="password" placeholder="Mot de passe"/>
              </div>

              <div class="toutou" style="margin: auto; width: 90px;">
                <input class="confirmer" type="submit" value="S'inscrire">
              </div>
            </form>

<!Conditions générales de vente/>
<!La div valider sert uniquement a placercocher/>
<!la div conditions_champs englobeobligatoire et les conditions/>

              <p class="valider1">
                <input class="checkbox" type="checkbox" name="j'accepte"/>
                J'accepte sans réserve <a id="conditions" href="">les conditions générales de vente</a> du site
              </p>
              <p class="valider2">
                  <input class="checkbox" type="checkbox" name="j'accepte"/>
                Je souhaite recevoir par mail les offres et réduction du site
              </p>
            <p class="champ">*Champs obligatoire</p>
        
        </div> 
<!Fin de la div principale/>
  </body>
<!DOCTYPE html>
<html>
<head>
	<title>accueil</title>
	<meta charset="utf-8">
	
</head>
<body>

<div id="page">

<h1>OL LIBRARY</h1>

<p>Arrivée sur le site le <?php echo date('d/m/Y à h:i:s'); ?> </p>

<ul>
	<li class="btn1">
		<button class="bouton1"><a href="/olibrairy/login/">Login</a></button>
	</li>
</ul>
</div>

</body>
</html>


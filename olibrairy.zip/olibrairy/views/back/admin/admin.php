<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
    
    <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      
      <a href="/olibrairy"><img src="/olibrairy/images/book-flat.png" style="width: 50px; height: 50px; margin-right: 20px;">Retour Accueil</a>
      
    </div>

    <!-- Collect the nav links, forms, and other content for toggli<button type="button" class="btn btn-default">ng -->
    <button style="margin-left: 10px;margin-top: 7px;" type="button" class="btn btn-default"> 
        <a href="/olibrairy/deconnexion/">Deconnexion</a>
    </button>
      
      <ul class="nav navbar-nav navbar-right">
        <li><a class="navbar-right" href="/olibrairy/newadmin/">Créer un new ADMIN</a></li>
        <li><a href="/olibrairy">Back to home</a></li>
        <li><a href="/olibrairy/affichage/">Users list</a></li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>




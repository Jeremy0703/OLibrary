<!DOCTYPE html>
<html>
<head>
    <title>update</title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="css\front_accueil\styles.css">
</head>
<body>

        <h3>     •   MODIFIS-TOI</h3>
        <form method="POST" action="">
            <input type="text" name="prenom" value="<?= $user["prenom"];?>"/>
            <input type="text" name="nom" value="<?= $user["nom"];?>"/>
            <input type="text" name="email" value="<?= $user["email"];?>"/>
            <input type="hidden" name="id" value="<?= $user["id"];?>"/>

            <input type="password" name="password" />
            <input type="submit" value="modifier"/>
</form>

</body>
</html>



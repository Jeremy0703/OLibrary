<?php
$_SESSION["connect"] = false;
$_SESSION["erreur"] = "Vous vous êtes bien déconnectés avec succés. Bonne continuation.";
header("Location: http://localhost/olibrairy/login/");
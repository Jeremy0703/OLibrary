<?php
if(!$_SESSION["connectasadmin"])
{
	$_SESSION["erreur"] = "Veuillez vous connecter avec des identifiants valides pour accéder à la page http://localhost/olibrairy/connected";
	header("Location: http://localhost/olibrairy/login/");
}

if(!empty($_SESSION["erreur"]))
{
	echo "<div>".$_SESSION["erreur"]."</div>";
	unset($_SESSION["erreur"]);
	

}
require $_dir["views"]."back/admin/admin.php";
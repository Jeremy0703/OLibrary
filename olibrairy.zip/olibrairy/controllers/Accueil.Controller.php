<?php
require $_dir["views"]."front/accueil.php";
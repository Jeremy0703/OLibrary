<?php


if(!empty($_GET["id"]))
{
	$_SESSION["erreur"] = false;
    $bdd->query("DELETE FROM users WHERE id= ".$_GET["id"]." ");
    header("Location: http://localhost/olibrairy/admin/");
}



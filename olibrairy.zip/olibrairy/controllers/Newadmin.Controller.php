<?php 
require $_dir["views"]."back/admin/newadmin.php";

if(!empty($_POST))
{
    
    $bdd->query("INSERT INTO admin (nom,prenom,email,password)
   VALUES ('".$_POST["nom"]."', '".$_POST["prenom"]."', '".$_POST["email"]."', '".md5($_POST["password"])."') ");

    echo "<div style='font-size: 18px; float: left; width: 50%;margin-left: 27.5%;text-align: center; color: DarkSlateGray; border: 5px solid red; margin-bot: 100px;'>L'administrateur a bien été créé. Merci à vous ".$_POST["prenom"]." et bonne continuation !</div>";

}
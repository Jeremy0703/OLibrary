<?php

if(!empty($_POST))
{
    
    $bdd->query("INSERT INTO users (nom,prenom,email,password)
   VALUES ('".$_POST["nom"]."', '".$_POST["prenom"]."', '".$_POST["email"]."', '".md5($_POST["password"])."') ");

    echo "Votre utilisateur a bien été créé. Merci à vous ".$_POST['prenom']." et bonne continuation !";

    
}


?>
<?php
require $_dir["views"]."back/admin/affichage.php";
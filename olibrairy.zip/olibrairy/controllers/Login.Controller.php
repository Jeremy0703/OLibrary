<?php
if(!empty($_POST))
{
	$normal = $bdd->query("SELECT * FROM users 
		WHERE email='".$_POST["email"]."'
		AND password='".md5($_POST["password"])."' ");
	$user = $normal->fetch();

	$pasnormal = $bdd->query("SELECT * FROM admin 
		WHERE email='".$_POST["email"]."' 
		AND password='".md5($_POST["password"])."' ");
	$admin = $pasnormal->fetch();

	if(!empty($user)) //si login/mdp est bon pour user
	{
		$_SESSION["connect"] = true;

		header('Location: http://localhost/olibrairy/connected/');
	}
	else if(!empty($admin)) // si le email/mdp est bon pour admin
	{
			$_SESSION["connectasadmin"] = true;
			header('Location: http://localhost/olibrairy/admin/');
	}
	else
	{
		$_SESSION["erreur"] = "VEUILLEZ SAISIR DES INFORMATIONS VALIDES";
	}

	
}
	if(!empty($_SESSION["erreur"]))
{
	echo 
	"<div>
	".$_SESSION["erreur"]."
	</div>";
	unset($_SESSION["erreur"]);
	
}
require $_dir["views"]."login.php";
<?php

$_dir["controllers"] = "controllers/";
$_dir["views"] = "views/";

$config = array(
	"loginBDD" => "gaby",
	"mdpBDD" => "gaby",
	"base" => "cours",
	);

	